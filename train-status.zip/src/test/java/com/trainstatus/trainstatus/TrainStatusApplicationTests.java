package com.trainstatus.trainstatus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainStatusApplicationTests {

	@Test
	void contextLoads() {
	}

}
